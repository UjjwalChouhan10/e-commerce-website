const API = "http://localhost:5000/api";

function getToken() {
    return localStorage.getItem("token");
}

function setToken(token) {
    localStorage.setItem("token", token);
}

function logout() {
    localStorage.removeItem("token");
    window.location.href = "login.html";
}

// ---------------- AUTH ----------------
async function signup() {
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    await fetch(`${API}/signup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, email, password })
    });
    alert("Signup successful, please login.");
    window.location.href = "login.html";
}

async function login() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const res = await fetch(`${API}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (data.token) {
        setToken(data.token);
        window.location.href = "index.html";
    } else {
        alert(data.msg || "Login failed");
    }
}

// ---------------- ITEMS ----------------
async function loadItems() {
    const category = document.getElementById("category")?.value;
    const minPrice = document.getElementById("minPrice")?.value;
    const maxPrice = document.getElementById("maxPrice")?.value;

    let url = `${API}/items?`;
    if (category) url += `category=${category}&`;
    if (minPrice) url += `minPrice=${minPrice}&`;
    if (maxPrice) url += `maxPrice=${maxPrice}`;

    const res = await fetch(url);
    const items = await res.json();
    const div = document.getElementById("items");
    if (!div) return;
    div.innerHTML = "";
    items.forEach(i => {
        div.innerHTML += `<div>${i.name} - $${i.price} 
      <button onclick="addToCart('${i._id}')">Add to Cart</button></div>`;
    });
}

async function addToCart(id) {
    const token = getToken();
    if (!token) { alert("Login first!"); return; }
    await fetch(`${API}/cart/${id}`, {
        method: "POST",
        headers: { "Authorization": "Bearer " + token }
    });
    alert("Item added to cart");
}

// ---------------- CART ----------------
async function loadCart() {
    const token = getToken();
    const res = await fetch(`${API}/cart`, {
        headers: { "Authorization": "Bearer " + token }
    });
    const cart = await res.json();
    const div = document.getElementById("cart");
    if (!div) return;
    div.innerHTML = "";
    cart.forEach(i => {
        div.innerHTML += `<div>${i.name} - $${i.price} 
      <button onclick="removeFromCart('${i._id}')">Remove</button></div>`;
    });
}

async function removeFromCart(id) {
    const token = getToken();
    await fetch(`${API}/cart/${id}`, {
        method: "DELETE",
        headers: { "Authorization": "Bearer " + token }
    });
    loadCart();
}

// Auto-load content if on correct page
if (window.location.pathname.endsWith("index.html")) loadItems();
if (window.location.pathname.endsWith("cart.html")) loadCart();

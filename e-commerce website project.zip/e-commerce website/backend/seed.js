const mongoose = require("mongoose");
const Item = require("./models/Item");

mongoose.connect("mongodb://localhost:27017/ecommerce").then(async () => {
    await Item.deleteMany({});
    await Item.insertMany([
        { name: "Shoes", price: 50, category: "Fashion" },
        { name: "Laptop", price: 700, category: "Electronics" },
        { name: "Phone", price: 300, category: "Electronics" }
    ]);
    console.log("Items seeded");
    mongoose.disconnect();
});

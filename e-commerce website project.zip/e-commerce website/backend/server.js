const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const User = require("./models/User");
const Item = require("./models/Item");

const app = express();
app.use(express.json());
app.use(cors());

const JWT_SECRET = "secret_key"; // use env variable in real app

// ---------------- Middleware ----------------
const auth = (req, res, next) => {
    const token = req.headers["authorization"]?.split(" ")[1];
    if (!token) return res.status(401).json({ msg: "No token" });
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch {
        res.status(401).json({ msg: "Invalid token" });
    }
};

// ---------------- Auth APIs ----------------
app.post("/api/signup", async (req, res) => {
    const { username, email, password } = req.body;
    const hashed = await bcrypt.hash(password, 10);
    try {
        await User.create({ username, email, password: hashed });
        res.json({ msg: "User created" });
    } catch {
        res.status(400).json({ msg: "Email already exists" });
    }
});

app.post("/api/login", async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: "User not found" });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ msg: "Wrong password" });
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: "1d" });
    res.json({ token });
});

// ---------------- Item APIs ----------------
app.post("/api/items", auth, async (req, res) => {
    const item = await Item.create(req.body);
    res.json(item);
});

app.get("/api/items", async (req, res) => {
    const { category, minPrice, maxPrice } = req.query;
    let filter = {};
    if (category) filter.category = category;
    if (minPrice || maxPrice) filter.price = {};
    if (minPrice) filter.price.$gte = Number(minPrice);
    if (maxPrice) filter.price.$lte = Number(maxPrice);
    const items = await Item.find(filter);
    res.json(items);
});

app.put("/api/items/:id", auth, async (req, res) => {
    const updated = await Item.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
});

app.delete("/api/items/:id", auth, async (req, res) => {
    await Item.findByIdAndDelete(req.params.id);
    res.json({ msg: "Deleted" });
});

// ---------------- Cart APIs ----------------
app.post("/api/cart/:itemId", auth, async (req, res) => {
    const user = await User.findById(req.user.id);
    user.cart.push(req.params.itemId);
    await user.save();
    res.json(await user.populate("cart"));
});

app.get("/api/cart", auth, async (req, res) => {
    const user = await User.findById(req.user.id).populate("cart");
    res.json(user.cart);
});

app.delete("/api/cart/:itemId", auth, async (req, res) => {
    const user = await User.findById(req.user.id);
    user.cart = user.cart.filter(id => id.toString() !== req.params.itemId);
    await user.save();
    res.json(await user.populate("cart"));
});

// ---------------- Start ----------------
mongoose.connect("mongodb://localhost:27017/ecommerce").then(() => {
    app.listen(5000, () => console.log("Backend running on http://localhost:5000"));
});
